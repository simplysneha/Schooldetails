var express = require("express");  
var path = require("path");  
var mongoose = require('mongoose');   
var bodyParser = require('body-parser');   
var morgan = require("morgan");  
var db = require("./config.js");  
var ejs = require('ejs');

var app = express();  
var port = process.env.port || 8888;  
var srcpath  =path.join(__dirname,'/public') ;  
app.use(express.static('public'));  
app.use(bodyParser.json());    
app.use(bodyParser.urlencoded({extended:true}));  
  
// Database Connectivity
var Schema = mongoose.Schema;  
var schoolSchema = new Schema({      
    schoolid: { type: String, unique : true, dropDups: true ,required:true },       
    schoolname: { type: String ,required:true  },
    schooldoe:{ type:Number, dropDups: true ,required:true },
    schoolboard:{type: String, dropDups: true, required: true},
    schooladdress:{ type:String,unique : true, required: true},
    schoolno:{ type: String ,required:true}
                
},{ versionKey: false });  
var model = mongoose.model('school', schoolSchema, 'school');  



app.get('/about', function (req, res) {  
   console.log("Got a GET request for /about");  
   res.render('about_1.ejs');
})

//api for INSERT data from database  
app.post("/api/savedata",function(req,res){   
       
    var mod = new model(req.body);  
	req.body.serverMessage = "NodeJS replying to REACT"
	mod.save(function (err, result){                       
        if(err) 
		{ 
			console.log(err.message); 
			//res.send("Duplicate School ID")
			res.json({
			status: 'fail'
		    })
		} 
		else
		{
            console.log('School registered');
			/*Sending the respone back to the angular Client */
			res.json({
			msg: 'We received your data!!!(nodejs)',
			status: 'success',mydata:req.body
			})
		}
       })     
})  

 // get data from database DISPLAY  
 app.get('/display', function (req, res) { 
//------------- USING EMBEDDED JS -----------
 model.find().sort({schoolid:1}).exec(
 		function(err , i){
        if (err) return console.log(err)
        res.render('displayall_1.ejs',{schoolinfo: i})  
     })
//---------------------// sort({empid:-1}) for descending order -----------//
})


  


//--------------SEARCH------------------------------------------
app.get('/search.html', function (req, res) {  
   res.sendFile( __dirname + "/" + "search.html" );    
})

app.get("/search", function(req, res) {
	//var schoolidnum=parseInt(req.query.schoolid)  // if empid is an integer
	var schoolidnum=req.query.schoolid;
	model.find({schoolid: schoolidnum},{schoolname:1,schoolid:1,schoolno:1,schooldoe:1,schooladdress:1,schoolboard:1,_id:0}).exec(function(err, docs) {
    if (err) {
      console.log(err.message+ "Failed to get data.");
    } else
	{
	if (docs=='')
		res.send("<br/>"+schoolidnum+":"+"<b>School Not Found</b>")
	else
	    res.render('displayid_1.ejs',{schoolinfo:docs});
	}
  });
  })

app.get('/searchbyname.html', function (req, res) {  
   res.sendFile( __dirname + "/" + "searchbyname.html" );    
})

app.get("/searchbyname", function(req, res) {
	//var schoolidnum=parseInt(req.query.schoolid)  // if empid is an integer
	var schoolname=req.query.schoolname;

model.find({schoolname: new RegExp('^'+schoolname, "i")}, function(err, docs) {
  //Do your action here..
 if (err) {
      console.log(err.message+ "Failed to get data.");
    } else
	{
	if (docs=='')
		res.send("<br/>"+schoolname+":"+"<b>School Not Found</b>")
        else if (docs==null)
		res.send("<br/>"+schoolname+":"+"<b>School Not Found</b>")
	else
	    res.render('displayname_1.ejs',{schoolinfo:docs});
	}

});
})
// call by default index.html page  
app.get("*",function(req,res){   
    res.sendFile(srcpath +'/index.html');  
})   
//server stat on given port  
app.listen(port,function(){   
    console.log("server start on port:"+ port);  
})   